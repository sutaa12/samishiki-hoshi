export default {
  "bootstrapScriptContent": "import(\"/_next/static/chunks/index-R0RzrE6R.js\")",
  "clientReferenceDeps": {
    "e988af9e0617": {
      "js": [
        "/_next/static/chunks/game-client-C-J-11qK.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js",
        "/_next/static/chunks/runtime-cleanup-tombstone-CcAEmowS.js",
        "/_next/static/chunks/three.tsl-2isI_JY2.js",
        "/_next/static/chunks/contract-lab-Bmtl1313.js",
        "/_next/static/chunks/index-R0RzrE6R.js"
      ],
      "css": []
    },
    "8a96732ec522": {
      "js": [
        "/_next/static/chunks/gfx-contract-client-BXs8J1XV.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js",
        "/_next/static/chunks/contract-lab-Bmtl1313.js",
        "/_next/static/chunks/three.tsl-2isI_JY2.js",
        "/_next/static/chunks/index-R0RzrE6R.js"
      ],
      "css": [
        "/_next/static/css/gfx-contract-client.BHWZX2sS.css"
      ]
    },
    "3784f75c831a": {
      "js": [
        "/_next/static/chunks/gfx-foundation-client-DmLIAf7g.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js",
        "/_next/static/chunks/runtime-cleanup-tombstone-CcAEmowS.js",
        "/_next/static/chunks/three.tsl-2isI_JY2.js",
        "/_next/static/chunks/contract-lab-Bmtl1313.js",
        "/_next/static/chunks/index-R0RzrE6R.js"
      ],
      "css": [
        "/_next/static/css/gfx-foundation-client.Dpw5TMOa.css"
      ]
    },
    "19a00229a720": {
      "js": [
        "/_next/static/chunks/gfx-hero-a-client-C7a3kBcc.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js",
        "/_next/static/chunks/runtime-cleanup-tombstone-CcAEmowS.js",
        "/_next/static/chunks/three.tsl-2isI_JY2.js",
        "/_next/static/chunks/contract-lab-Bmtl1313.js",
        "/_next/static/chunks/index-R0RzrE6R.js"
      ],
      "css": [
        "/_next/static/css/gfx-hero-a-client.88n9e0cq.css"
      ]
    },
    "817f3c75dd88": {
      "js": [
        "/_next/static/chunks/gfx-hero-b-client-BcRyGOca.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js",
        "/_next/static/chunks/runtime-cleanup-tombstone-CcAEmowS.js",
        "/_next/static/chunks/three.tsl-2isI_JY2.js",
        "/_next/static/chunks/contract-lab-Bmtl1313.js",
        "/_next/static/chunks/index-R0RzrE6R.js"
      ],
      "css": [
        "/_next/static/css/gfx-hero-b-client.CwdTscDR.css"
      ]
    },
    "8877bd01bf3a": {
      "js": [
        "/_next/static/chunks/gfx-hero-c-client-C943b0un.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js",
        "/_next/static/chunks/runtime-cleanup-tombstone-CcAEmowS.js",
        "/_next/static/chunks/three.tsl-2isI_JY2.js",
        "/_next/static/chunks/contract-lab-Bmtl1313.js",
        "/_next/static/chunks/index-R0RzrE6R.js"
      ],
      "css": [
        "/_next/static/css/gfx-hero-c-client.DQXbUOGg.css"
      ]
    },
    "2a11aac8247c": {
      "js": [
        "/_next/static/chunks/gfx-spike-client-Ca-ZWENU.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js",
        "/_next/static/chunks/three.tsl-2isI_JY2.js",
        "/_next/static/chunks/index-R0RzrE6R.js"
      ],
      "css": [
        "/_next/static/css/gfx-spike-client.CZuzXPQC.css"
      ]
    },
    "9276801271d6": {
      "js": [
        "/_next/static/chunks/index-R0RzrE6R.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    },
    "0b874ad30386": {
      "js": [
        "/_next/static/chunks/index-R0RzrE6R.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    },
    "593f344dc510": {
      "js": [
        "/_next/static/chunks/index-R0RzrE6R.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    },
    "bad85346fc72": {
      "js": [
        "/_next/static/chunks/index-R0RzrE6R.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    },
    "15c18cfaeeff": {
      "js": [
        "/_next/static/chunks/layout-segment-context-C5ETeBjo.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-R0RzrE6R.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    },
    "8c0f216c4604": {
      "js": [
        "/_next/static/chunks/index-R0RzrE6R.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-BgSIrAUN.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.D7baJSDR.css"
      ]
    }
  }
}